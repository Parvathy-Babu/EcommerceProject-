<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-8">
                    <div class="pull-left">
                        <h2>Orders List</h2>
                    </div>
                </div>
                <div class="pull-left">
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="pull-left mb-2">
                        <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Show Products</a>
                    </div>
                </div>
                <div class="col-md-8"></div>
                <div class="col-md-2">
                    <div class="pull-left mb-2">
                        <a class="btn btn-success" href="<?php echo e(route('orders.create')); ?>"> Add Order</a>
                    </div>
                </div>
            </div>
        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Phone</th>
                    <th>Net Amount</th>
                    <th>Order Date</th>
                    <th width="280px">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($order->orderId); ?></td>
                        <td><?php echo e($order->customerName); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->orderAmount); ?></td>
                        <td><?php echo e(date('d M Y', strtotime($order->created_at ))); ?></td>
                        <td>
                            <form action="<?php echo e(route('orders.destroy',$order->id)); ?>" method="Post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $orders->links(); ?>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\electronic_items\resources\views/orders/index.blade.php ENDPATH**/ ?>