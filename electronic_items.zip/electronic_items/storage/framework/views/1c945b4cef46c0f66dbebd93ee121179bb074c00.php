<nav class=" d-none d-md-block bg-light sidebar">
    <div class="sidebar-sticky">
        <form>
            <div class=" input-group">
                <input class="form-control" type="text" placeholder="Search...">
                <button type="submit" class="btn btn-primary" value="search">Search</button>
            </div>
        </form>
            <h2>No category to show</h2>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\electronic_items\resources\views/products/sidebar.blade.php ENDPATH**/ ?>