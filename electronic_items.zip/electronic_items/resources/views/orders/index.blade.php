<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-8">
                    <div class="pull-left">
                        <h2>Orders List</h2>
                    </div>
                </div>
                <div class="pull-left">
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="pull-left mb-2">
                        <a class="btn btn-primary" href="{{ route('products.index') }}"> Show Products</a>
                    </div>
                </div>
                <div class="col-md-8"></div>
                <div class="col-md-2">
                    <div class="pull-left mb-2">
                        <a class="btn btn-success" href="{{ route('orders.create') }}"> Add Order</a>
                    </div>
                </div>
            </div>
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Phone</th>
                    <th>Net Amount</th>
                    <th>Order Date</th>
                    <th width="280px">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->orderId }}</td>
                        <td>{{ $order->customerName }}</td>
                        <td>{{ $order->phone }}</td>
                        <td>{{ $order->orderAmount }}</td>
                        <td>{{ date('d M Y', strtotime($order->created_at ));}}</td>
                        <td>
                            <form action="{{ route('orders.destroy',$order->id) }}" method="Post">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
            </tbody>
        </table>
        {!! $orders->links() !!}
    </div>
</body>
</html>
