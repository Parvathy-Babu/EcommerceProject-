<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-8">
                    <div class="pull-left">
                        <h2>Products Management</h2>
                    </div>
                </div>
                <div class="pull-left">
                </div>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <div class="pull-left mb-2">
                        <a class="btn btn-primary" href="{{ route('products.create') }}"> Create products</a>
                    </div>
                </div>
                <div class="col-md-8"></div>
                <div class="col-md-2">
                    <div class="pull-left mb-2">
                        <a class="btn btn-success" href="{{ route('orders.create') }}"> Add Order</a>
                    </div>
                </div>
            </div>
        @if ($message = Session::get('success'))
            <div class="alert alert-success">
                <p>{{ $message }}</p>
            </div>
        @endif
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Products</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th width="280px">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($products as $product)
                    <tr>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->category }}</td>
                        <td>{{ $product->price }}</td>
                        <td>
                            <form action="{{ route('products.destroy',$product->id) }}" method="Post">
                                <a class="btn btn-primary" href="{{ route('products.edit',$product->id) }}">Edit</a>
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
            </tbody>
        </table>
        {!! $products->links() !!}
    </div>
</body>
</html>
