<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Orders;
use App\Models\Products;
use PDF;


class OrderController extends Controller
{
    /**
     * Loading orders list
     * @return \Illuminate\Http\Response

    */
    public function index()
    {
        $orders = Orders::orderBy('id','desc')->paginate(5);
        return view('orders.index', compact('orders'));
    }
   /**
     * Loading order create form
     * @return \Illuminate\Http\Response

    */
    public function create()
    {
        $products = Products::orderBy('id','desc')->paginate(5);
        return view('orders.create',compact('products'));
    }
    
    /**
    * Store order into db.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'mobileno' => 'required',
            'product_id' => 'required',
            'quantity' => 'required'
        ]);
        $product_rate = Products::where('id',$request->get('product_id') )->first(['price'])->price;
        $total_amount = $product_rate * $request->get('quantity');
        $order_id=random_int(10000, 99999);
        $order = new Orders([
            'orderId' => $order_id,
            'productId' => $request->get('product_id'),
            'customerName' => $request->get('name'),
            'phone' => $request->get('mobileno'),
            'category' => $request->get('category'),
            'quantity' => $request->get('quantity'),
            'orderAmount' => $total_amount
        ]);
        $order->save(); //  Save the record.
        return redirect()->route('orders.index')->with('success','Order Placed successfully.Your total order amount is Rs '.$total_amount );
    }
   
    /**
    * Remove an order.
    *
    * @param  \App\Orders  $order
    * @return \Illuminate\Http\Response
    */
    public function destroy(Orders $order)
    {
        $order->delete();
        return redirect()->route('orders.index')->with('success','Order removed successfully');
    }
    /**
     * Generate PDF
     */
    public function invoice() {
        // retreive all records from db
        $data = Orders::all();
        // share data to view
        view()->share('employee',$data);
        $pdf = PDF::loadView('pdf_view', $data);
        // download PDF file with download method
        return $pdf->download('pdf_file.pdf');
      }
  
}
