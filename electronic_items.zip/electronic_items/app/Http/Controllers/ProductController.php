<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;
use App\Models\Orders;

class ProductController extends Controller
{
    /**
     * Loading product list
     * @return \Illuminate\Http\Response

    */
    public function index()
    {
        $products = Products::orderBy('id','desc')->paginate(5);
        return view('products.index', compact('products'));
    }
    /**
     * Loading product create form
     * @return \Illuminate\Http\Response

    */
    public function create()
    {
        return view('products.create');
    }
    /**
     * Loading product details edit form
     * @param  \App\Products  $product
     * @return \Illuminate\Http\Response
    */
    public function edit(Products $product)
    {
        return view('products.edit',compact('product'));
    }
    /**
    * Store new product into db.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'image' => 'required',
            'category' => 'required',
            'price' => 'required'
        ]);
        // ensure the request has a file before we attempt anything else.
        if ($request->hasFile('image')) {
            $request->validate([
                'image' => 'mimes:jpeg,bmp,png' // Only allow .jpg, .bmp and .png file types.
            ]);

            // Save the file locally in the storage/public/ folder under a new folder named /product
           $file = $request->file('image')->store('products','public');

            // Store the record, using the new file hashname which will be it's new filename identity.
            $product = new Products([
                'name' => $request->get('name'),
                'image' => $request->file('image')->hashName(),
                'category' => $request->get('category'),
                'price' => $request->get('price')
            ]);
            $product->save(); // Finally, save the record.
        }
        return redirect()->route('products.index')->with('success','Product  added successfully.');
    }

    /**
    * Update a product details.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  \App\Products  $product
    * @return \Illuminate\Http\Response
    */
    public function update(Request $request, Products $product)
    {
        $request->validate([
            'name' => 'required',
            'category' => 'required',
            'price' => 'required',
        ]);
        
        $product->fill($request->post())->save();

        return redirect()->route('products.index')->with('success','Product details updated successfully');
    }
    /**
    * Remove a product.
    *
    * @param  \App\Products  $product
    * @return \Illuminate\Http\Response
    */
    public function destroy(Products $product)
    {
        $product->delete();
        return redirect()->route('products.index')->with('success','Product removed successfully');
    }
    
     
}
